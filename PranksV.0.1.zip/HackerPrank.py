import tkinter as tk
import time

window = tk.Tk()

window.title("RUN.")
window.geometry("800x400")
window.configure(background="black")

label = tk.Label(window, text="YOUR DEVICE HAS BEEN HACKED", fg="red", bg="black", font=("arial", 24))
label.pack(anchor="center")

label2 = tk.Label(window, text="THIS WINDOW WILL DISSAPEER ONCE WE HAVE SIEZED YOUR ASSETS, THERE IS NO WAY TO GET YOUR FILES BACK, DON'T TRY", fg="red", bg="black", font=("arial", 24), wraplength=800, justify="center")
label2.pack(anchor="center")

label.config(text="Or you can pay $300 in crypto")

label.config(text="OR YOU CAN Call: 480-438-2845")
window.after(3000, label2.destroy, label.destroy)


window.after(10000, window.destroy)
window.mainloop()