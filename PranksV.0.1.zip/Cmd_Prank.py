import tkinter as tk
import time

# Create the main window
window = tk.Tk()

# Set the window size and background color
window.geometry("800x400")
window.configure(bg="black")
window.title("Adminastrator: Command Prompt")

label = tk.Label(window, text="C:/Users/LocalPC/LocalHost? run IP_LOGGER.vbs", fg="White", bg="Black", font=("Arial", 13))
label.pack(side="left", anchor="n")

# Start the event loop and wait for a few seconds
window.after(500, window.destroy)
window.mainloop()